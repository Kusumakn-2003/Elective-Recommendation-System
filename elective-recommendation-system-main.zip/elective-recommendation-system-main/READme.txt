Always Run the app.py file before you start the index page.

Don't forget to replace the Logo path with your system's path

static --> index.html